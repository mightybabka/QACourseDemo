﻿using OpenQA.Selenium;

namespace SeleniumWebDriverFirstTests.Pages.SideBarPage
{
    public partial class SideBarPage : BasePage
    {
        public SideBarPage(IWebDriver driver) 
            : base (driver)
        {
        }
    }
}
