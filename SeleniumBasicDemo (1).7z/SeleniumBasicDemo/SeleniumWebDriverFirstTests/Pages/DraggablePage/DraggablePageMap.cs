﻿namespace SeleniumWebDriverFirstTests.Pages.DraggablePage
{
    public partial class DraggablePage
    {
    }
}
