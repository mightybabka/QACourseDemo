﻿namespace ClassesDemo
{
    public class SpecificPerson : Person
    {

        public void IsVisible()
        {

        }
    }
}
